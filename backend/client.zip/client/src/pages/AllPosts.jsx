import React, { useEffect, useState } from "react";
import { fetchAllPosts } from "../../services/api";
import PostCard from "../../components/PostCard";
import { usePostStore } from "../store/usePostStore.js";

const AllPosts = () => {
    const { } = usePostStore();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const loadPosts = async () => {
      try {
        const res = await fetchAllPosts();
        setPosts(res.data.posts); // backend should return {posts: [...]}
      } catch (err) {
        setError(err.response?.data?.message || "Failed to load posts");
      } finally {
        setLoading(false);
      }
    };

    loadPosts();
  }, []);

  if (loading) return <p className="text-center text-gray-600">Loading posts...</p>;
  if (error) return <p className="text-center text-red-500">{error}</p>;

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4 text-center">All Posts</h1>
      <div className="grid gap-4">
        {posts.map((post) => (
          <PostCard key={post._id} post={post} />
        ))}
      </div>
    </div>
  );
};

export default AllPosts;
