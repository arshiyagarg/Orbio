import React from "react";

const PostCard = ({ post }) => {
  return (
    <div className="border rounded-lg p-4 shadow-md hover:shadow-lg transition">
      <h2 className="text-xl font-semibold">{post.title}</h2>
      {/* <p className="text-gray-700 mt-2">{post.content}</p> */}
      <p className="text-sm text-gray-500 mt-4">
        Author: <span className="font-medium">{post.author?.fullName || "Unknown"}</span>
      </p>
      <p className="text-sm text-gray-400">
        {new Date(post.createdAt).toLocaleString()}
      </p>
    </div>
  );
};

export default PostCard;
